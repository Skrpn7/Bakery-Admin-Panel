
const Backend_Url = 'http://localhost:5001'



export default Backend_Url;
